package com.example.task71p;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.example.task71p.data.DatabaseHelper;
import com.example.task71p.model.User;

import java.util.ArrayList;
import java.util.List;

public class FindActivity extends AppCompatActivity {

    ListView advertListView;

    ArrayList<String> advertArrayList;
    ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_find);

        advertListView = findViewById(R.id.listViewItems);

        advertArrayList = new ArrayList<>();
        DatabaseHelper db = new DatabaseHelper(FindActivity.this);

        List<User> userList = db.fetchAllAdverts();

        for (User user :userList)
        {
            advertArrayList.add(user.getName() + ": " + user.getDescription() + "...");
        }

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, advertArrayList);
        advertListView.setAdapter(adapter);

        advertListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                Intent intent = new Intent(getApplicationContext(), DetailActivity.class);
                intent.putExtra("advert_id", userList.get(position).getAdvertId());
                intent.putExtra("name", userList.get(position).getName());
                intent.putExtra("phone", userList.get(position).getPhone());
                intent.putExtra("description", userList.get(position).getDescription());
                intent.putExtra("date", userList.get(position).getDate());
                intent.putExtra("location", userList.get(position).getLocation());
                intent.putExtra("latitude", userList.get(position).getLatitude());
                intent.putExtra("longitude", userList.get(position).getLongitude());
                startActivity(intent);
            }
        });
    }
}
