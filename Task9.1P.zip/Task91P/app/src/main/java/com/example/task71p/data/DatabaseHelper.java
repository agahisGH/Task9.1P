package com.example.task71p.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import com.example.task71p.model.User;
import com.example.task71p.util.Util;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {
    public DatabaseHelper(@Nullable Context context) {
        super(context, Util.DATABASE_NAME, null, Util.DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String CREATE_USER_TABLE = "CREATE TABLE " + Util.TABLE_NAME + "(" + Util.ADVERT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT , "
                + Util.TYPE + " TEXT, " + Util.NAME + " TEXT, " + Util.PHONE + " TEXT, " + Util.DESCRIPTION + " TEXT, " + Util.DATE + " TEXT, " + Util.LOCATION + " TEXT, " + Util.LATITUDE + " DOUBLE, " + Util.LONGITUDE + " DOUBLE)";

        sqLiteDatabase.execSQL(CREATE_USER_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        String DROP_USER_TABLE = "DROP TABLE IF EXISTS " + Util.DATABASE_NAME; //???
        sqLiteDatabase.execSQL(DROP_USER_TABLE, new String[]{Util.TABLE_NAME});

        onCreate(sqLiteDatabase);
    }

    public long insertAdvert(User user)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put(Util.TYPE, user.getType());
        contentValues.put(Util.NAME, user.getName());
        contentValues.put(Util.PHONE, user.getPhone());
        contentValues.put(Util.DESCRIPTION, user.getDescription());
        contentValues.put(Util.DATE, user.getDate());
        contentValues.put(Util.LOCATION, user.getLocation());
        contentValues.put(Util.LATITUDE, user.getLatitude());
        contentValues.put(Util.LONGITUDE, user.getLongitude());

        long newRowId = db.insert(Util.TABLE_NAME, null, contentValues);
        db.close();
        return newRowId;
    }

    public int removeAdvert(long id)
    {
        SQLiteDatabase db = this.getWritableDatabase(); // added

        String whereArgs[] = {""+id};
        int count = db.delete(Util.TABLE_NAME, Util.ADVERT_ID + "=?", whereArgs);
        return count;
    }

    public boolean fetchUser(String type, String name, String phone, String description, String date, String location)
    {
        SQLiteDatabase db = this.getReadableDatabase();
            Cursor cursor = db.query(Util.TABLE_NAME, new String[]{Util.ADVERT_ID}, Util.TYPE + "=? and " + Util.NAME + "=?" + Util.PHONE + "=?" + Util.DESCRIPTION + "=?" + Util.DATE + "=?" + Util.LOCATION + "=?",
                new String[] {type, name, phone, description, date, location}, null, null, null, null);

        int numberOfRows = cursor.getCount();
        db.close();

        if (numberOfRows > 0)
            return true;
        else
            return false;
    }

    public List<User> fetchAllAdverts(){
        List<User> advertList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String selectAll = " SELECT * FROM " + Util.TABLE_NAME;
        Cursor cursor = db.rawQuery(selectAll, null);

        if (cursor.moveToFirst())
        {
            do {
                User user = new User();
                user.setAdvertId(cursor.getInt(0));
                user.setType(cursor.getString(1));
                user.setName(cursor.getString(2));
                user.setPhone(cursor.getString(3));
                user.setDescription(cursor.getString(4));
                user.setDate(cursor.getString(5));
                user.setLocation(cursor.getString(6));
                user.setLatitude(cursor.getDouble(7));
                user.setLongitude(cursor.getDouble(8));

                advertList.add(user);

            } while (cursor.moveToNext());

        }

        return advertList;
    }
}
