package com.example.task71p;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.example.task71p.data.DatabaseHelper;
import com.example.task71p.model.User;

import org.w3c.dom.Text;

public class CreateActivity extends AppCompatActivity {

    DatabaseHelper db;

    RadioGroup radioGroup;
    RadioButton radioButton;

    EditText name;
    EditText phone;
    EditText description;
    EditText date;
    EditText locationBox;

    Button saveButton;

    LocationManager locationManager;
    LocationListener locationListener;

    double latitude, longitude;

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED){
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListener);
            }
        }
    }

    Button getCurrentLocation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create);

        radioGroup = findViewById(R.id.radioGroup);

        name = findViewById(R.id.editTextName);
        phone = findViewById(R.id.editTextPhone);
        description = findViewById(R.id.editTextDescription);
        date = findViewById(R.id.editTextDate);

        locationBox = findViewById(R.id.editTextLocation);
        locationBox.setText(" ", TextView.BufferType.EDITABLE);

        saveButton = findViewById(R.id.buttonSave);

        getCurrentLocation = findViewById(R.id.buttonGetLocation);

        Intent intent = getIntent();
        String locationName = intent.getStringExtra("locationName");
        latitude = intent.getDoubleExtra("latitudeSend", 0);
        longitude = intent.getDoubleExtra("longitudeSend", 0);

        locationBox.setText(locationName);

        locationBox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentPlaces = new Intent(CreateActivity.this, PlacesActivity.class);
                startActivity(intentPlaces);
            }
        });

        getCurrentLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                locationManager = (LocationManager) CreateActivity.this.getSystemService(LOCATION_SERVICE);
                locationListener = new LocationListener() {
                    @Override
                    public void onLocationChanged(@NonNull Location location) {
                        //location = location.getName();
                        latitude = location.getLatitude();
                        longitude = location.getLongitude();

                        locationBox.setText("Deakin University Burwood Campus");
                        getCurrentLocation.setBackgroundColor(getResources().getColor(com.google.android.libraries.places.R.color.quantum_lightgreen));
                        //Toast.makeText(CreateActivity.this, "Current Location Saved", Toast.LENGTH_SHORT).show();
                        //locationBox.setVisibility(View.INVISIBLE);
                    }
                };

                if (ActivityCompat.checkSelfPermission(CreateActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(CreateActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    // TODO: Consider calling
                    //    ActivityCompat#requestPermissions
                    // here to request the missing permissions, and then overriding
                    //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                    //                                          int[] grantResults)
                    // to handle the case where the user grants the permission. See the documentation
                    // for ActivityCompat#requestPermissions for more details.
                    ActivityCompat.requestPermissions(CreateActivity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
                }
                else {
                    locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListener);
                }
            }
        });

        db = new DatabaseHelper(this);

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String stype = radioButton.getText().toString();
                String sname = name.getText().toString();
                String sphone = phone.getText().toString();
                String sdescription = description.getText().toString();
                String sdate = date.getText().toString();
                String slocation = locationBox.getText().toString();

                //add check for radio buttons...

                if (sname.isEmpty() || sphone.isEmpty() || sdescription.isEmpty() || sdate.isEmpty() || slocation.isEmpty())
                {
                    Toast.makeText(CreateActivity.this, "Please fill in all fields!", Toast.LENGTH_SHORT).show();
                }

                else
                {
                    long result = db.insertAdvert(new User(stype, sname, sphone, sdescription, sdate, slocation, latitude, longitude));

                    if (result > 0)
                    {
                        Toast.makeText(CreateActivity.this, "Success", Toast.LENGTH_SHORT).show();
                    }
                    else
                    {
                        Toast.makeText(CreateActivity.this, "Fail", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }

    public void checkRadioButton(View v)
    {
        int radioId = radioGroup.getCheckedRadioButtonId();
        radioButton = findViewById(radioId);

        Toast.makeText(this, "Selected Radio Button: " + radioButton.getText(), Toast.LENGTH_SHORT).show();
    }
}
