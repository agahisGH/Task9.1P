package com.example.task71p;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.common.api.Status;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.api.net.PlacesClient;
import com.google.android.libraries.places.widget.Autocomplete;
import com.google.android.libraries.places.widget.AutocompleteSupportFragment;
import com.google.android.libraries.places.widget.listener.PlaceSelectionListener;

import java.util.Arrays;

public class PlacesActivity extends AppCompatActivity {

    private static final String TAG = "Running";
    Place place;

    double latitude;
    double longitude;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_place);

        // from here below clean up...
        Places.initialize(getApplicationContext(), "${KEY_PLACES}");
        PlacesClient placesClient = Places.createClient(this);

        // Initialize the AutocompleteSupportFragment.
        AutocompleteSupportFragment autocompleteFragment = (AutocompleteSupportFragment)
                getSupportFragmentManager().findFragmentById(R.id.autocomplete_fragment);

        // Specify the types of place data to return.
        autocompleteFragment.setPlaceFields(Arrays.asList(Place.Field.ID, Place.Field.NAME, Place.Field.LAT_LNG));

        // Set up a PlaceSelectionListener to handle the response.
        autocompleteFragment.setOnPlaceSelectedListener(new PlaceSelectionListener() {
            @Override
            public void onPlaceSelected(@NonNull Place place) {
                // TODO: Get info about the selected place.
                latitude = place.getLatLng().latitude;
                longitude = place.getLatLng().longitude;

                Toast.makeText(PlacesActivity.this, "LatLng: " + latitude, Toast.LENGTH_SHORT).show();

                Intent intentNew = new Intent(PlacesActivity.this, CreateActivity.class);
                intentNew.putExtra("locationName", place.getName());
                intentNew.putExtra("latitudeSend", latitude);
                intentNew.putExtra("longitudeSend", longitude);
                startActivity(intentNew);
            }

            @Override
            public void onError(@NonNull Status status) {
                // TODO: Handle the error.
                Log.i(TAG, "An error occurred: " + status);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 1) {
            if (resultCode == RESULT_OK)
            {
                //Log.i(TAG, "Place: " + place.getName() + ", LatLng: " + place.getLatLng());
                Log.i(TAG, "LatLng TEST: " + place.getLatLng());
                finishActivity(1);
            }
            else if (resultCode == 0)
            {
                Status status = Autocomplete.getStatusFromIntent(data);
                Log.i(TAG, status.getStatusMessage());
                finishActivity(1);
            }
            else if (resultCode == RESULT_CANCELED)
            {
                finishActivity(1);
            }

            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }
}
